package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "C:\\Users\\a868548\\Downloads\\github\\feature\\login.feature"
        ,glue = {"stepdefinition"}
        ,plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
        ,monochrome = true
        ,publish = true
        )

public class Run extends AbstractTestNGCucumberTests {

}
