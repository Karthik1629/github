package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PageObject {
	WebDriver driver;
	By signin=By.xpath("/html/body/div[1]/div[1]/header/div/div[2]/div/div/div[2]/a");
	By username=By.xpath("//input[@name='login']");
	By pass=By.xpath("//input[@name='password']");
	By submit=By.xpath("//input[@name='commit']");
	
	By verify=By.xpath("/html/body/div[1]/div[6]/div/aside/div/loading-context/div/div[1]/div/h2/text()");
	
}
