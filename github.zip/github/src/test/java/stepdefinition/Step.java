package stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Step  {
	WebDriver driver;
	@Given("open a GitHub website")
	public void open_a_git_hub_website() {
	   WebDriverManager.edgedriver().setup();
	   driver= new EdgeDriver();
	   driver.get("https://github.com/login");
	}
	
}