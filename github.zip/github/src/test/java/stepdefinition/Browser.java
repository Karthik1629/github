package stepdefinition;

public class Browser {
  
	String browser="firefox";
}
