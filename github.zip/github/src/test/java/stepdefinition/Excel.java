package stepdefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	Cell cell,cell1,cell2;

	public void main(String[] args) throws IOException {
		File file= new File("C:\\Users\\a868592\\eclipse-workspace\\TrainingAssignment\\Excel\\Data Modular.xlsx");
	    FileInputStream fin = new FileInputStream(file);
	    Workbook w = new XSSFWorkbook(fin);
	    Sheet s = w.getSheet("Sheet1");
	    Row row = s.getRow(0);
	    cell = row.getCell(0);
	    Row row1=s.getRow(1);
	    cell1=row1.getCell(1);
	    Row row2=s.getRow(2);
	    cell2=row2.getCell(2);
		

	}

	
}
